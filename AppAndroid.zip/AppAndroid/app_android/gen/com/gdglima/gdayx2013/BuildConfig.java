/** Automatically generated file. DO NOT MODIFY */
package com.gdglima.gdayx2013;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}