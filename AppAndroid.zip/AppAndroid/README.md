gdayx2013
=========

Repositorio Dev Fest GDG/GBG Lima 2013

Google Play services 3.2
http://venomvendor.blogspot.com/2012/03/android-sdk-extras-by-google-inc.html

ActionBarSherlock
https://github.com/JakeWharton/ActionBarSherlock

